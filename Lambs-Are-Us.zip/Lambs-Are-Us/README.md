# Lambs-Are-Us Restaurant System

### Main Sub-Components:
- Purchasing Management System
- Inventory Management System
